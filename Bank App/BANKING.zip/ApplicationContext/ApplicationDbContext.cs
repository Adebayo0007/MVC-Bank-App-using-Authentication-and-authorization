using Microsoft.EntityFrameworkCore;
using MVC_MobileBankApp.Models;

namespace MVC_MobileBankApp.ApplicationContext
{
    public class ApplicationDbContext : DbContext
    {
     
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base (options)
        {
            
        }
        public DbSet<Admin> Admins   {get; set;}
        
    
    }
}