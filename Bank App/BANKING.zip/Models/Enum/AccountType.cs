namespace MobileBankApp
{
    public enum AccountType
    {
        Student = 1,
        Savings,
        Current,
        Business,
        Joint,
    }
}