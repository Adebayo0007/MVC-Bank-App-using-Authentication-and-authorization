namespace MobileBankApp.Enum
{
    public enum GenderType
    {
        Male = 1,
        Female
    }
}