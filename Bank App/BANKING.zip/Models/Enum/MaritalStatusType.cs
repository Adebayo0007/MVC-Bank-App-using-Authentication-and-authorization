namespace MobileBankApp.Enum
{
    public enum MaritalStatusType
    {
        Single = 1,
        Married,
        Divorced,
        Taken,
        

    }
}