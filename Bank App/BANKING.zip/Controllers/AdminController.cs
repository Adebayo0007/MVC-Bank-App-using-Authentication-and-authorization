using Microsoft.AspNetCore.Mvc;
using MVC_MobileBankApp.Models;
using MVC_MobileBankApp.Services.Interfaces;

namespace MVC_MobileBankApp.Controllers
{
    public class AdminController : Controller
    {
        private readonly IAdminService _service;

        public AdminController(IAdminService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult IndexPage()
        {
            return View();
        }

        public IActionResult CreateAdmin()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
         public IActionResult CreateAdmin(Admin admin)
        {
            if(admin != null)
            {
                _service.CreateAdmin(admin);
                TempData["success"] = "Admin Created Successfully";
                return RedirectToAction(nameof(IndexPage));
            }
            else
            {
                ViewBag.Error = "Wrong Input";
               return View();
            }

           
            
        }

         public IActionResult DeleteAdmin(string staffId)
        {
            if(staffId == null)
            {
                return NotFound();
            }
            var admin = _service.GetAdminById(staffId);
            if(admin == null)
            {
                return NotFound();
            }
            return View(admin);
        }

        [HttpPost , ActionName("DeleteAdmin")]
         public IActionResult DeleteConfirmed(string staffId)
        {
            _service.DeleteAdminUsingId(staffId);
            return RedirectToAction(nameof(IndexPage));
        }

         public IActionResult LogIn()
        {
           return View();
           
        }

        [HttpPost , ActionName("LogIn")]
         public IActionResult LogInConfirmed(string email,string passWord)
        {
            if(email == null || passWord == null)
            {
                return NotFound();
            }
            var admin = _service.Login(email,passWord);
            if (admin == null)
            {
                 ViewBag.Error = "Invalid Email or PassWord";
                return View();
            }
            else
            {
            return RedirectToAction(nameof(IndexPage));
            }
           
            
        }


        
         public IActionResult Admins()
        {
            var admins = _service.GetAllAdmin();
            return View(admins);
        }

         [HttpGet("{staffId}")]
         public IActionResult Details(string staffId)
        {
            var admin = _service.GetAdminById(staffId);
            return View(admin);
            return RedirectToAction(nameof(Admins));
        }


        
    }
}